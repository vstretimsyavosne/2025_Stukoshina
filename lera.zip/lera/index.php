<?php
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include 'header.php';

// Обработка отметки времени
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $date = date('Y-m-d');
    $time = date('H:i:s');
    $user_id = $_SESSION['user_id'];
    
    // Проверяем, есть ли уже запись на сегодня
    $sql = "SELECT * FROM time_records WHERE user_id = $user_id AND date = '$date'";
    $result = $conn->query($sql);
    
    if ($action === 'time_in') {
        if ($result->num_rows === 0) {
            // Проверяем опоздание (после 9:30)
            $is_late = (strtotime($time) > strtotime('09:30:00')) ? 1 : 0;
            
            $sql = "INSERT INTO time_records (user_id, date, time_in, is_late) 
                    VALUES ($user_id, '$date', '$time', $is_late)";
            $conn->query($sql);
        }
    } elseif ($action === 'time_out') {
        if ($result->num_rows === 1) {
            $record = $result->fetch_assoc();
            if (!$record['time_out']) {
                $sql = "UPDATE time_records SET time_out = '$time' WHERE id = {$record['id']}";
                $conn->query($sql);
            }
        }
    }
    
    header('Location: index.php');
    exit();
}

// Получаем текущий статус
$date = date('Y-m-d');
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM time_records WHERE user_id = $user_id AND date = '$date'";
$result = $conn->query($sql);
$today_record = $result->num_rows === 1 ? $result->fetch_assoc() : null;

// Получаем статистику за текущий месяц
$month = date('m');
$year = date('Y');
$sql = "SELECT COUNT(*) as late_count FROM time_records 
        WHERE user_id = $user_id AND is_late = TRUE 
        AND MONTH(date) = $month AND YEAR(date) = $year";
$result = $conn->query($sql);
$late_count = $result->fetch_assoc()['late_count'];
?>

<div class="row">
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Отметка времени</h5>
            </div>
            <div class="card-body text-center">
                <?php if (!$today_record || !$today_record['time_in']): ?>
                    <form method="post">
                        <input type="hidden" name="action" value="time_in">
                        <button type="submit" class="btn btn-success btn-lg py-3">
                            <i class="bi bi-box-arrow-in-right"></i> Отметить приход
                        </button>
                    </form>
                <?php elseif (!$today_record['time_out']): ?>
                    <form method="post">
                        <input type="hidden" name="action" value="time_out">
                        <button type="submit" class="btn btn-danger btn-lg py-3">
                            <i class="bi bi-box-arrow-right"></i> Отметить уход
                        </button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-info">
                        Вы уже отметили и приход, и уход на сегодня.
                    </div>
                <?php endif; ?>
                
                <?php if ($today_record): ?>
                    <div class="mt-4">
                        <p>Приход: <?= $today_record['time_in'] ?></p>
                        <p>Уход: <?= $today_record['time_out'] ?: 'еще не отмечен' ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Статистика за месяц</h5>
            </div>
            <div class="card-body">
                <p>Количество опозданий: <strong><?= $late_count ?></strong></p>
                
                <h5 class="mt-4">Последние записи</h5>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Дата</th>
                                <th>Приход</th>
                                <th>Уход</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT * FROM time_records WHERE user_id = $user_id 
                                    ORDER BY date DESC LIMIT 5";
                            $result = $conn->query($sql);
                            
                            while ($row = $result->fetch_assoc()): ?>
                                <tr class="<?= $row['is_late'] ? 'late-row' : '' ?>">
                                    <td><?= $row['date'] ?></td>
                                    <td><?= $row['time_in'] ?></td>
                                    <td><?= $row['time_out'] ?: '-' ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>