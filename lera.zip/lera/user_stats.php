<?php
include 'config.php';

// Проверяем права администратора
if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit();
}

// Получаем ID пользователя из GET-параметра
$user_id = intval($_GET['id'] ?? 0);
if ($user_id <= 0) {
    header('Location: admin.php');
    exit();
}

// Получаем информацию о пользователе
$sql = "SELECT * FROM users WHERE id = $user_id";
$result = $conn->query($sql);
if ($result->num_rows === 0) {
    header('Location: admin.php');
    exit();
}
$user = $result->fetch_assoc();

// Получаем статистику пользователя
$sql = "SELECT * FROM time_records WHERE user_id = $user_id ORDER BY date DESC";
$records_result = $conn->query($sql);

// Получаем количество опозданий
$sql = "SELECT COUNT(*) as late_count FROM time_records 
        WHERE user_id = $user_id AND is_late = TRUE";
$late_result = $conn->query($sql);
$late_count = $late_result->fetch_assoc()['late_count'];

include 'header.php';
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Статистика пользователя: <?= htmlspecialchars($user['full_name']) ?></h2>
        <a href="admin.php" class="btn btn-secondary">Назад</a>
    </div>

    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Общая статистика</h5>
        </div>
        <div class="card-body">
            <p>Количество опозданий: <strong><?= $late_count ?></strong></p>
            <p>Имя пользователя: <strong><?= htmlspecialchars($user['username']) ?></strong></p>
            <p>Роль: <strong><?= $user['is_admin'] ? 'Администратор' : 'Сотрудник' ?></strong></p>
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Записи по дням</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Дата</th>
                            <th>Приход</th>
                            <th>Уход</th>
                            <th>Опоздание</th>
                            <th>Отработано</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($record = $records_result->fetch_assoc()): ?>
                            <tr class="<?= $record['is_late'] ? 'late-row' : '' ?>">
                                <td><?= $record['date'] ?></td>
                                <td><?= $record['time_in'] ?></td>
                                <td><?= $record['time_out'] ?: '-' ?></td>
                                <td><?= $record['is_late'] ? 'Да' : 'Нет' ?></td>
                                <td>
                                    <?php 
                                    if ($record['time_in'] && $record['time_out']) {
                                        $time_in = strtotime($record['time_in']);
                                        $time_out = strtotime($record['time_out']);
                                        $diff = $time_out - $time_in;
                                        echo gmdate('H:i', $diff);
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>