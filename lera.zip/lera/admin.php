<?php
include 'config.php';

if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit();
}

include 'header.php';

// Добавление нового пользователя
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $full_name = $conn->real_escape_string($_POST['full_name']);
    $is_admin = isset($_POST['is_admin']) ? 1 : 0;
    
    $sql = "INSERT INTO users (username, password, full_name, is_admin) 
            VALUES ('$username', '$password', '$full_name', $is_admin)";
    $conn->query($sql);
    
    $_SESSION['message'] = "Пользователь $username успешно добавлен";
    header('Location: admin.php');
    exit();
}

// Получаем список всех пользователей
$sql = "SELECT * FROM users ORDER BY is_admin DESC, full_name ASC";
$users_result = $conn->query($sql);

// Получаем статистику опозданий за текущий месяц
$month = date('m');
$year = date('Y');
$sql = "SELECT u.id, u.full_name, COUNT(t.id) as late_count 
        FROM users u LEFT JOIN time_records t 
        ON u.id = t.user_id AND t.is_late = TRUE 
        AND MONTH(t.date) = $month AND YEAR(t.date) = $year 
        GROUP BY u.id ORDER BY late_count DESC";
$stats_result = $conn->query($sql);
?>

<div class="row">
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Добавить пользователя</h5>
            </div>
            <div class="card-body">
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-success"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
                <?php endif; ?>
                
                <form method="post">
                    <div class="mb-3">
                        <label for="username" class="form-label">Имя пользователя</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Пароль</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Полное имя</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" required>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="is_admin" name="is_admin">
                        <label class="form-check-label" for="is_admin">Администратор</label>
                    </div>
                    <button type="submit" name="add_user" class="btn btn-primary">Добавить</button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Статистика опозданий</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Сотрудник</th>
                                <th>Опоздания</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $stats_result->fetch_assoc()): ?>
                                <tr class="<?= $row['late_count'] > 0 ? 'late-row' : '' ?>">
                                   

<td><a href="user_stats.php?id=<?= $user['id'] ?>"><?= htmlspecialchars($row['full_name']) ?></a></td>
                                    <td><?= $row['late_count'] ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">Все пользователи</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Имя пользователя</th>
                        <th>Полное имя</th>
                        <th>Роль</th>
                        <th>Дата регистрации</th>
                        <th>Опоздания</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // Получаем список пользователей с количеством опозданий
                    $sql = "SELECT u.*, 
                           (SELECT COUNT(*) FROM time_records t 
                            WHERE t.user_id = u.id AND t.is_late = TRUE) as late_count
                           FROM users u ORDER BY u.is_admin DESC, u.full_name ASC";
                    $users_result = $conn->query($sql);
                    
                    while ($user = $users_result->fetch_assoc()): 
                        $has_late = $user['late_count'] > 0;
                    ?>
                        <tr class="<?= $has_late ? 'table-danger' : '' ?>">
                            <td><?= $user['id'] ?></td>
                            <td><?= htmlspecialchars($user['username']) ?></td>
                            <td><a href="user_stats.php?id=<?= $user['id'] ?>"><?= htmlspecialchars($user['full_name']) ?></a></td>
                            <td><?= $user['is_admin'] ? 'Администратор' : 'Сотрудник' ?></td>
                            <td><?= $user['created_at'] ?></td>
                            <td><?= $user['late_count'] ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>